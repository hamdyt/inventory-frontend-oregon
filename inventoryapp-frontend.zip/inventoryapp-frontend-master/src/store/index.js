import configureStore from './configure'

export default configureStore()
