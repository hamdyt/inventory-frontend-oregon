const config = {
  cognito: {
    REGION: 'us-east-2',
    USER_POOL_ID: 'us-east-2_hGQJWXq4A',
    APP_CLIENT_ID: '31u87c05v3rdkck58uircs8t9k'
  }
}

export default config
