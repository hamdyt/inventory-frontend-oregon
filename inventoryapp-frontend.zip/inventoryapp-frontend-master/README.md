# Inventoryapp Frontend

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Key lib included

- CSS modules
- node-sass
- redux
- redux-pender
- react-helmet
